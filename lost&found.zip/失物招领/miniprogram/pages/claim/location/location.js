var app = getApp();
function fixZero(num) {
  return num < 10 ? '0' + num : num;
}
/**时间格式为两位数**/
// pages/home/home.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    characteristicList:[{
      text: "免配送费"
    },{
      text: "0元起送"
    },{
      text: "新商家"
    },{
      text: "品牌商家"
    },{
      text: "跨天预定"
    }],
    sortList:[{
      sort: "综合排序",
      image:"",
    }, {
      sort: "速度最快",
      image: "",
    }, {
      sort: "评分最高",
      image: "",
    }, {
      sort: "起送价最低",
      image: "",
    }, {
      sort: "配送费最低",
      image: "",
    }],
    discountList:[{
      icon: "减",
      iconColor: "#FF635B", 
      text: "满减优惠"
    },{
      icon: "领",
      iconColor: "#FF7298", 
      text: "进店领券"
    },{
      icon: "返",
      iconColor: "#FB4343", 
      text: "满返代金券"
    },{
      icon: "折",
      iconColor: "#C183E2", 
      text: "折扣商品"
    },{
      icon: "订",
      iconColor: "#6FDF64", 
      text: "提前下单优惠"
    },{
      icon: "赠",
      iconColor: "#FDC41E", 
      text: "满赠活动"
    },{
      icon: "免",
      iconColor: "#43B697", 
      text: "满免配送"
    }],
    categoryList:{
      pageone:[{
        name: "美食",
        src: "/pages/images/1.png"
      }, {
        name: "甜点饮品",
        src: "/pages/images/2.png"
      }, {
        name: "美团超市",
        src: "/pages/images/3.png"
      }, {
        name: "正餐精选",
        src: "/pages/images/4.png"
      }, {
        name: "生鲜果蔬",
        src: "/pages/images/5.png"
      }, {
        name: "全部商家",
        src: "/pages/images/6.png"
      }, {
        name: "免配送费",
        src: "/pages/images/7.png"
      }, {
        name: "新商家",
        src: "/pages/images/8.png"
      }],
      pagetwo: [{
        name: "美食",
        src: "/pages/images/1.png"
      }, {
        name: "甜点饮品",
        src: "/pages/images/2.png"
      }, {
        name: "美团超市",
        src: "/pages/images/3.png"
      }, {
        name: "正餐精选",
        src: "/pages/images/4.png"
      }, {
        name: "生鲜果蔬",
        src: "/pages/images/5.png"
      }, {
        name: "全部商家",
        src: "/pages/images/6.png"
      }, {
        name: "免配送费",
        src: "/pages/images/7.png"
      }, {
        name: "新商家",
        src: "/pages/images/8.png"
      }]
    },
    selected: 0,
    mask1Hidden: true,
    mask2Hidden: true,
    animationData: "",
    location: "",
    latitude:"",
    longitude:"",
    characteristicSelected: [false,false,false,false,false,false,false],
    discountSelected:null,
    selectedNumb: 0,
    sortSelected: "综合排序",
    claim: [],
    searchKey: '',
    search: [],
    bindtapSearch: false,
    distance: []
  },
  // finish: function () {
  //   var that = this;
  //   wx.request({
  //     url: "https://www.easy-mock.com/mock/596257bc9adc231f357c4664/restaurant/filter",
  //     method: "GET",
  //     success: function (res) {
  //       that.setData({
  //         restaurant: res.data.data.restaurant,
  //       })
  //     }
  //   });
  // },
  // sortSelected: function (e) {
  //   var that = this;
  //   wx.request({
  //     url: "https://www.easy-mock.com/mock/596257bc9adc231f357c4664/restaurant/overAll",
  //     method: "GET",
  //     success: function (res) {
  //       that.setData({
  //         restaurant: res.data.data.restaurant,
  //         sortSelected: that.data.sortList[e.currentTarget.dataset.index].sort
  //       })
  //     }
  //   });
  // },
  clearSelectedNumb: function () {
    this.setData({
      characteristicSelected: [false],
      discountSelected: null,
      selectedNumb: 0
    })
  },
  characteristicSelected: function (e) {
    var info = this.data.characteristicSelected;
    info[e.currentTarget.dataset.index] = !info[e.currentTarget.dataset.index];
    this.setData({
      characteristicSelected: info,
      selectedNumb: this.data.selectedNumb + (info[e.currentTarget.dataset.index]?1:-1)
    })
    console.log(e.currentTarget.dataset.index);
  },
  discountSelected: function (e) {
    if (this.data.discountSelected != e.currentTarget.dataset.index){
      this.setData({
        discountSelected: e.currentTarget.dataset.index,
        selectedNumb: this.data.selectedNumb+(this.data.discountSelected==null?1:0)
      })
    }else{
      this.setData({
        discountSelected: null,
        selectedNumb: this.data.selectedNumb - 1
      })
    }
  },
  onTapTag: function (e) {
    this.setData({
      selected: e.currentTarget.dataset.index
    });
  },
  mask1Cancel: function () {
    this.setData({
      mask1Hidden: true
    })
  },
  mask2Cancel: function () {
    this.setData({
      mask2Hidden: true
    })
  },
  onOverallTag: function () {
    this.setData({
      mask1Hidden: false
    })
  },
  onFilter: function () {
    this.setData({
      mask2Hidden: false
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    that.getData();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  // onShow: function () {
  //   this.getData();
  //   var that = this;
  //   wx.request({
  //     url: "https://www.easy-mock.com/mock/596257bc9adc231f357c4664/restaurant/info",
  //     method: "GET",
  //     success: function (res) {
  //       that.setData({
  //         location: wx.getStorageSync('location')
  //       })
  //     }
  //   });
  // },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
  getData: function () {
    var that = this;
    wx.cloud.callFunction({
      // 云函数名称
      name: 'database',
      // 传给云函数的参数
      data: {
        type: 'get',
        getType: 'getCentre'
      },
      success: function (res) {
        console.log('获取成功', res);
        var result = res.result || {};
        that.dealData(result.data, function (data) {
          that.setData({
            claim: result.data
          });
        });
        wx.getLocation({
          type: 'gcj02',
          success: function (res) {
            var latitude = res.latitude
            var longitude = res.longitude
            that.setData({
              'latitude': res.latitude,
              'longitude': res.longitude
            })
            wx.cloud.callFunction({
              // 云函数名称
              name: 'getDistance',
              // 传给云函数的参数
              data: {
                type:'get',
                userLatitude:that.data.latitude,
                userLongitude:that.data.longitude,
                latitude1: that.data.claim[0].latitude,
                longitude1: that.data.claim[0].longitude,
                latitude2: that.data.claim[1].latitude,
                longitude2: that.data.claim[1].longitude,
                latitude3: that.data.claim[2].latitude,
                longitude3: that.data.claim[2].longitude,
                latitude4: that.data.claim[3].latitude,
                longitude4: that.data.claim[3].longitude,
                latitude5: that.data.claim[4].latitude,
                longitude5: that.data.claim[4].longitude,
                latitude6: that.data.claim[5].latitude,
                longitude6: that.data.claim[5].longitude,
                latitude7: that.data.claim[6].latitude,
                longitude7: that.data.claim[6].longitude,
                latitude8: that.data.claim[7].latitude,
                longitude8: that.data.claim[7].longitude,  
                latitude9: that.data.claim[8].latitude,
                longitude9: that.data.claim[8].longitude,              
              }, //计算距离
              success: function(res) {
                  res.result = JSON.parse(res.result);
                  console.log('success')
                  for (let i = 0; i < res.result.result.elements.length; i++) {
                    var up = "claim[" + i + "].distance";//先用一个变量，把(info[0].gMoney)用字符串拼接起来
                    var down = "claim[" + i + "].duration";
                    console.log('ddd',[up])
                    that.setData({
                      [up]:(Number(res.result.result.elements[i].distance)/1000).toFixed(2),
                      [down]:(Number(res.result.result.elements[i].duration)/60).toFixed(0)
                    })
                  } //把距离和时间传入claim数组中
                  that.data.claim.sort(function (a,b){
                    if (Number(a.distance) < Number(b.distance)) {
                      return -1;
                    } else if (Number(a.distance) == Number(b.distance)) {
                      return 0;
                    } else {
                      return 1;
                    }
                  }); //排序
                  that.setData({
                    claim:that.data.claim
                  }) //更新
                  console.log(that.data.claim);
                },
              fail: function() {
                console.log('fail')
              }
            });
            wx.request({
              url: 'https://apis.map.qq.com/ws/geocoder/v1/?location='+ latitude + ',' + longitude + '&key=IFFBZ-XUQRX-TV44Z-TINVJ-U6NPQ-SZFJ5',
              method: "get",
              success: function (res) {     
                console.log(res)
                that.setData({
                  'location': res.data.result.address_reference.landmark_l2.title
                })
              }
            });
          }
        });
      },
      fail: function () { }
    })
  },

  dealData: function (claim, callback) {
    claim.forEach(function (item) { /**循环遍历list**/
      var date = new Date(item.time);

      item.timeInfo = {
        year: date.getFullYear(),
        month: fixZero(date.getMonth() + 1),
        /**从0开始计算，所以加1**/
        date: fixZero(date.getDate()),
        hours: fixZero(date.getHours()),
        minutes: fixZero(date.getMinutes())
      };
    });
    callback(claim);
  },

  bindtapSearch: function () {
    var that = this;
    that.setData({
      bindtapSearch: true,
      search: []
    });
    that.getData();
    /**重新搜索时获取全部数据**/
  },

  onInputSearch: function (event) {
    var that = this;
    var data = that.data;    
    that.setData({
      search:[],
      'searchKey': event.detail.value,
      /**清除search之前的数据**/
    });
    for (let i = 0; i < data.claim.length; i++) {
      if (data.claim[i].name.indexOf(data.searchKey) >= 0) {
        data.search.push(data.claim[i])
      }
    }
  },
  /**实现关键字搜索功能**/

  onSearch: function (event) {
    // this.getSearchData();
    this.setData({
      claim:this.data.search,
      bindtapSearch: false
    });
    console.log(this.data.claim)
  },

  getSearchData: function () {
    var that = this;
    wx.cloud.callFunction({
      // 云函数名称
      name: 'database',
      // 传给云函数的参数
      data: {
        type: 'get',
        getType: 'getSearchCentre',
        search: that.data.search
      },
      success: function (res) {
        console.log('获取成功');
        console.log(res);
        var result = res.result || {};
        that.dealData(result.data, function (data) {
          that.setData({
            claim: result.data
          });
        });
      },
      fail: function () { }
    })
  },

  button1: function (){
    var that = this;
    var data = that.data;    
    that.setData({
      search:[],
      'searchKey': '中国科学技术大学',
      /**清除search之前的数据**/
    });
    for (let i = 0; i < data.claim.length; i++) {
      if (data.claim[i].name.indexOf(data.searchKey) >= 0) {
        data.search.push(data.claim[i])
      }
    }
    this.onSearch();
  },

  button2: function () {
    var that = this;
    var data = that.data;    
    that.setData({
      search:[],
      'searchKey': '安徽大学',
      /**清除search之前的数据**/
    });
    for (let i = 0; i < data.claim.length; i++) {
      if (data.claim[i].name.indexOf(data.searchKey) >= 0) {
        data.search.push(data.claim[i])
      }
    }
    this.onSearch();
  },

  button3: function () {
    var that = this;
    var data = that.data;    
    that.setData({
      search:[],
      'searchKey': '合肥工业大学',
      /**清除search之前的数据**/
    });
    for (let i = 0; i < data.claim.length; i++) {
      if (data.claim[i].name.indexOf(data.searchKey) >= 0) {
        data.search.push(data.claim[i])
      }
    }
    this.onSearch();
  },

  button4: function () {
    this.setData({
      search: []
    });
    this.data.search.push('身份证');
    this.onSearch();
  },

  button5: function () {
    this.setData({
      search: []
    });
    this.data.search.push('学生证');
    this.onSearch();
  },
  
  onOpenSearchDetail: function (event) {
    var dataset = event.currentTarget.dataset || {};
    var item = this.data.claim[dataset.index];
    if (item.distance >0.05) {
    /**item即列表第几个数据**/
    let plugin = requirePlugin('routePlan');
    let key = 'H3LBZ-LVD33-KQU3N-3NAZL-JGZ53-WQFOP';  //使用在腾讯位置服务申请的key
    let referer = '帮你找失物招领';   //调用插件的app的名称
    let endPoint = JSON.stringify({  //终点
        'name': item.name,
        'latitude': parseFloat(item.latitude),
        'longitude': parseFloat(item.longitude)
    });
    wx.navigateTo({
        url: 'plugin://routePlan/index?key=' + key + '&referer=' + referer + '&navigation=1' + '&endPoint=' + endPoint
    });
  } else {
    wx.navigateTo({
      url: '/pages/claim/claim?location=' + item.name + '&latitude=' + item.latitude + '&longitude=' + item.longitude,  
  });
  }
    // wx.cloud.callFunction({
    //   // 云函数名称
    //   name: 'database',
    //   // 传给云函数的参数
    //   data: {
    //     type: 'upDate',
    //     id: item._id,
    //     updateType: 'users',
    //   },
    //   /**记录点开失物用户的openid**/
    //   success: function (res) {
        // wx.navigateTo({
        //   url: '/pages/search/search'
        // });
    //   },
    //   fail: function () { }
    // })
  },

  onShareAppMessage: function (event) {
    return {
      title: '有你丢的东西吗？'
    }
  }
})