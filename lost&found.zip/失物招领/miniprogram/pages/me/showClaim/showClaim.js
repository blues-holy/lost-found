function fixZero(num) {
  return num < 10 ? '0' + num : num;
}
/**时间格式为两位数**/

Page({
  data: {
    honorButton: true,
    picker: [],
    owner: [],
    button: false,
    record: [],
    nickName: '',
    honor: false,
    honorNumber: 0,
    timeInfo: []
  },
  onLoad: function (options) {
    this.getPickerRecord();
    this.getOwnerRecord();
  },

  getPickerRecord: function () {
    var that = this;

    wx.cloud.callFunction({
      // 云函数名称
      name: 'database',
      // 传给云函数的参数
      data: {
        type: 'getData',
        getType: 'getPickerRecord',
      },
      success: function (res) {
        console.log('获取成功');
        console.log(res);
        var result = res.result || {};
        that.dealPickerData(result.data, function (data) {
          that.setData({
            picker: result.data
          });
        });
      },
      fail: function () { }
    })
  },

  getOwnerRecord: function () {
    var that = this;

    wx.cloud.callFunction({
      // 云函数名称
      name: 'database',
      // 传给云函数的参数
      data: {
        type: 'getData',
        getType: 'getOwnerRecord',
      },
      success: function (res) {
        console.log('获取成功');
        console.log(res);
        var result = res.result || {};
        that.dealOwnerData(result.data, function (data) {
          that.setData({
            owner: result.data
          });
        });
      },
      fail: function () { }
    })
  },

  dealPickerData: function (picker, callback) {
    picker.forEach(function (item) { /**循环遍历**/
      var date = new Date(item.time);

      item.timeInfo = {
        year: date.getFullYear(),
        month: fixZero(date.getMonth() + 1),
        /**从0开始计算，所以加1**/
        date: fixZero(date.getDate()),
        hours: fixZero(date.getHours()),
        minutes: fixZero(date.getMinutes())
      };

    });
    callback(picker);
  },

  dealOwnerData: function (owner, callback) {
    owner.forEach(function (item) { /**循环遍历list**/
      var date = new Date(item.time);

      item.timeInfo = {
        year: date.getFullYear(),
        month: fixZero(date.getMonth() + 1),
        /**从0开始计算，所以加1**/
        date: fixZero(date.getDate()),
        hours: fixZero(date.getHours()),
        minutes: fixZero(date.getMinutes())
      };

    });
    callback(owner);
  },

  getUserInfo: function (event) {
    console.log('用户信息', event);
    var that = this;
    var data = that.data;

    wx.getUserInfo({
      success: function (res) { }
    })
    that.setData({
      'nickName': event.detail.userInfo.nickName
    });
    that.getRecord();
    that.setData({
      honor: true
    });
  },

  getRecord: function () {
    var that = this;
    var data = that.data;
    wx.cloud.callFunction({
      // 云函数名称
      name: 'record',
      // 传给云函数的参数
      data: {
        type: 'get',
        getType: 'getData'
      },
      success: function (res) {
        console.log('获取成功', res);
        var result = res.result || {};
        that.dealRecordData(result.data, function (data) {
          that.setData({
            record: result.data
          });
        });
        console.log('record', data.record);
        if (data.record.length == 0) {
          that.addToRecord();
        } else {
          that.updateRecord();
        }
      },
      fail: function () { }
    })
  },

  dealRecordData: function (record, callback) {
    record[0].claim.forEach(function (item) { /**循环遍历list**/
      var date = new Date(item.claimTime);

      item.timeInfo = {
        year: date.getFullYear(),
        month: fixZero(date.getMonth() + 1),
        /**从0开始计算，所以加1**/
        date: fixZero(date.getDate()),
        hours: fixZero(date.getHours()),
        minutes: fixZero(date.getMinutes())
      };

    });
    record[0].done.forEach(function (item) { /**循环遍历list**/
      var date = new Date(item.doneTime);

      item.timeInfo = {
        year: date.getFullYear(),
        month: fixZero(date.getMonth() + 1),
        /**从0开始计算，所以加1**/
        date: fixZero(date.getDate()),
        hours: fixZero(date.getHours()),
        minutes: fixZero(date.getMinutes())
      };

    });
    callback(record);
  },

  // dealRecordData: function () {
  //   for (let i = 0; i < this.data.record[0].claimTime.length; i++) {
  //     var date = new Date(this.data.record[0].claimTime[i]);
  //     this.data.record[0].claimTime.timeInfo = {
  //       year: date.getFullYear(),
  //       month: fixZero(date.getMonth() + 1),
  //       /**从0开始计算，所以加1**/
  //       date: fixZero(date.getDate()),
  //       hours: fixZero(date.getHours()),
  //       minutes: fixZero(date.getMinutes())
  //     };
  //     this.data.timeInfo.push(this.data.record[0].claimTime.timeInfo);
  //   }
  //   console.log('时间', this.data.timeInfo)
  //   this.setData({
  //     timeInfo: this.data.timeInfo
  //   });
  // },

  addToRecord: function () {
    var that = this;
    wx.cloud.callFunction({
      // 云函数名称
      name: 'record',
      // 传给云函数的参数
      data: {
        type: 'add',
        addType: 'newUser',
        nickName: that.data.nickName
      },
      success: function (res) {
        that.setData({
          honorNumber: 0
        });
      },
      fail: function () {
        console.log('fail')
      }
    });
  },

  updateRecord: function () {
    var data = this.data;
    this.setData({
      honorNumber: data.record[0].claim.length + data.record[0].done.length * 5
    });
    wx.cloud.callFunction({
      // 云函数名称
      name: 'record',
      // 传给云函数的参数
      data: {
        type: 'upDate',
        id: data.record[0]._id,
        updateType: 'honor',
        nickName: data.nickName,
      },
      success: function (res) { },
      fail: function () { }
    })
  },


  onOpenPickerDetail: function (event) {
    var dataset = event.currentTarget.dataset || {};
    var item = this.data.picker[dataset.index];
    /**item即列表第几个数据**/

    wx.cloud.callFunction({
      // 云函数名称
      name: 'database',
      // 传给云函数的参数
      data: {
        type: 'upDate',
        id: item._id,
        updateType: 'users',
      },
      /**记录点开失物用户的openid**/
      success: function (res) {
        wx.navigateTo({
          url: '/pages/recordDetail/recordDetail?id=' + item._id,
        });
      },
      fail: function () { }
    })
  },

  onOpenOwnerDetail: function (event) {
    var dataset = event.currentTarget.dataset || {};
    var item = this.data.owner[dataset.index];
    /**item即列表第几个数据**/

    wx.cloud.callFunction({
      // 云函数名称
      name: 'database',
      // 传给云函数的参数
      data: {
        type: 'upDate',
        id: item._id,
        updateType: 'users',
      },
      /**记录点开失物用户的openid**/
      success: function (res) {
        wx.navigateTo({
          url: '/pages/recordDetail/recordDetail?id=' + item._id,
        });
      },
      fail: function () { }
    })
  },

  onPicker: function () {
    this.setData({
      button: true
    });
  },

  onOwner: function () {
    this.setData({
      button: false
    });
  },

  onClaim: function () {
    this.setData({
      honorButton: true
    });
  },

  onDone: function () {
    this.setData({
      honorButton: false
    });
  },
  onToggle: function () {
    this.setData({
      honorButton: !this.data.honorButton,   /**按钮激活**/
      button: !this.data.honorButton,  /**按钮激活**/
    });
  },

})

