Page({
  data: {
    resource: {},
    ownerAnswer: '',
    right: 1,
    owner: true,
    ownerNickName: '',
    nickName: '',
    record: [],
    doneRecord: [],
    doneName: ''
  },

  onLoad: function(options) {
    /**获得id**/
    var that = this;

    wx.cloud.callFunction({
      // 云函数名称
      name: 'database',
      // 传给云函数的参数
      data: {
        type: 'getById',
        id: options.id
      },
      success: function(res) {
        that.setData({
          resource: res.result.data
        });
        console.log('sss', res);
      },
      fail: function() {}
    })
  },

  onInputOwnerAnswer: function(event) {
    this.setData({
      'ownerAnswer': event.detail.value /**获得输入信息**/
    });
  },

  onSave: function() {
    var data = this.data;

    if (data.ownerAnswer.length <= 1) {
      wx.showToast({
        title: '答案不能小于两个字',
        icon: 'none'
      });
      return;
    }
    /**答案不能为空，避免输入“色”为答案**/
    if (data.resource.notOwner.indexOf(data.resource.users) >= 0) {
      /**比对users和notOwner，如果点开的用户在回答错误的名单里，则展示不要重复回答**/
      this.setData({
        owner: false
      });
    } else if ((data.resource.name == '校园卡' || data.resource.name == '银行卡' || data.resource.name == '身份证' || data.resource.name == '一卡通' || data.resource.name == '工作证' || data.resource.name == '学生证') && data.ownerAnswer == data.resource.answer)
    /**卡类证件类要求答案完全一样**/
    {
      this.setData({
        right: 2
      });
    } else if (!(data.resource.name == '校园卡' || data.resource.name == '银行卡' || data.resource.name == '身份证' || data.resource.name == '一卡通' || data.resource.name == '工作证' || data.resource.name == '学生证') && (data.ownerAnswer.indexOf(data.resource.answer) >= 0 || data.resource.answer.indexOf(data.ownerAnswer) >= 0))
    /**其他类输入答案与正确答案有两字以上相同即判为正确**/
    {
      this.setData({
        right: 2
      });
    } else {
      this.setData({
        right: 4
      });
      data.resource.notOwner.push(data.resource.users);
      /**将回答错误用户openid传入notOwner数组**/
      wx.cloud.callFunction({
        // 云函数名称
        name: 'database',
        // 传给云函数的参数
        data: {
          type: 'upDate',
          id: data.resource._id,
          updateType: 'notOwner',
          notOwner: data.resource.notOwner
        },
        success: function(res) {},
        fail: function() {}
      })
    }
  },

  getUserInfo: function(event) {
    console.log('用户信息', event);
    var that = this;
    var data = that.data;

    wx.getUserInfo({
      success: function(res) {}
    })
    that.setData({
      'ownerNickName': event.detail.userInfo.nickName,
      'nickName': event.detail.userInfo.nickName
    });
    wx.cloud.callFunction({
      // 云函数名称
      name: 'database',
      // 传给云函数的参数
      data: {
        type: 'upDate',
        id: data.resource._id,
        updateType: 'owner',
        ownerNickName: data.ownerNickName,
      },
      /**将失主信息更新到云端**/
      success: function(res) {

      },
      fail: function() {}
    })
    that.setData({
      right: 3
    });
    that.getRecord();
    that.getDoneRecord();
  },

  getRecord: function() {
    var that = this;
    var data = that.data;
    wx.cloud.callFunction({
      // 云函数名称
      name: 'record',
      // 传给云函数的参数
      data: {
        type: 'get',
        getType: 'getData'
      },
      success: function(res) {
        console.log('获取成功', res);
        var result = res.result || {};
        that.setData({
          record: result.data
        });
        console.log('record', data.record);
        if (data.record.length == 0) {
          // that.addToRecord();
        } else {
          that.updateRecord();
        }
      },
      fail: function() {}
    })
  },

  addToRecord: function() {
    var that = this;
    wx.cloud.callFunction({
      // 云函数名称
      name: 'record',
      // 传给云函数的参数
      data: {
        type: 'add',
        addType: 'search',
        nickName: that.data.nickName
      },
      success: function(res) {},
      fail: function() {
        console.log('fail')
      }
    });
  },

  updateRecord: function() {
    var data = this.data;
    wx.cloud.callFunction({
      // 云函数名称
      name: 'record',
      // 传给云函数的参数
      data: {
        type: 'upDate',
        id: data.record[0]._id,
        updateType: 'search',
        nickName: data.nickName,
        searchNumber: data.record[0].searchNumber
      },
      success: function(res) {},
      fail: function() {}
    })
  },

  getDoneRecord: function() {
    var that = this;
    var data = that.data;
    wx.cloud.callFunction({
      // 云函数名称
      name: 'record',
      // 传给云函数的参数
      data: {
        type: 'get',
        getType: 'getDoneRecord',
        openid: data.resource.pickerOpenid
      },
      success: function(res) {
        console.log('获取成功', res);
        var result = res.result || {};
        that.setData({
          doneRecord: result.data
        });
        console.log('donerecord', data.doneRecord);
        if (data.doneRecord.length == 0) {
          that.addToDoneRecord();
        } else {
          that.updateDoneRecord();
        }
      },
      fail: function() {}
    })
  },

  addToDoneRecord: function () {
    var that = this;
    that.setData({
      'doneName': that.data.resource.name
    });
    wx.cloud.callFunction({
      // 云函数名称
      name: 'record',
      // 传给云函数的参数
      data: {
        type: 'add',
        addType: 'doneRecord',
        nickName: that.data.nickName,
        doneName: that.data.doneName
      },
      success: function (res) { },
      fail: function () {
        console.log('fail')
      }
    });
  },

  updateDoneRecord: function () {
    var data = this.data;
    this.setData({
      'doneName':data.resource.name
    });
    wx.cloud.callFunction({
      // 云函数名称
      name: 'record',
      // 传给云函数的参数
      data: {
        type: 'upDate',
        id: data.doneRecord[0]._id,
        updateType: 'doneRecord',
        doneName: data.doneName
      },
      success: function (res) { },
      fail: function () { }
    })
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function(event) {
    return {
      title: '是你丢的东西吗？'
    }
  }
})