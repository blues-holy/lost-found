// miniprogram/pages/cover/cover.js
Page({

  data: {
    showToolbar: false
  },

  onLoad: function (options) {
  },

  onToggle: function () {
    this.setData({
      showToolbar: !this.data.showToolbar   /**按钮激活**/
    });
  },

  onSearch: function () {
    wx.navigateTo({
      url: '/pages/search/search',
    });
  },

  onClaim: function () {
    wx.navigateTo({
      url: '/pages/claim/location/location',
    });
  },
  onRecord: function () {
    wx.navigateTo({
      url: '/pages/me/me',
    });
  },
  onBazaar: function () {
    wx.navigateTo({
      url: '/pages/bazaar/bazaar',
    });
  },
})