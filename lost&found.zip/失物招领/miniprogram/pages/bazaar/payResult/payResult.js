
var app = getApp();
Page({
    data: {
        status: 0,
        orderId: 0,
        is_over:0,
        productId:0,
        imageUrl:''
    },
    onLoad: function(options) {
        // 页面初始化 options为页面跳转所带来的参数
        console.log(options)
        this.setData({
            orderId: options.orderId,
            status: options.status
        })
    },
    toOrderListPage: function(event) {
        wx.redirectTo({
            url: '/pages/me/me',
        });
    },
    toIndex: function() {
        wx.redirectTo({
            url: '/pages/bazaar/bazaar'
        });
    },
    payOrder() {
        pay.payOrder(parseInt(this.data.orderId)).then(res => {
            this.setData({
                status: true
            });
        }).catch(res => {
            util.showErrorToast(res.errmsg);
        });
    }
})