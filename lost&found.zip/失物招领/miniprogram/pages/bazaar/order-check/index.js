// const app = getApp()

Page({
    data: {
        record:[],
        price: 0.00,
        addType: '',
        order:[],
        resource: {},
    },
    onLoad: function (options) {
        var that = this;
        that.getRecord();
        that.setData({
            'addType' : options.addtype,
            price: Number(options.price).toFixed(2)
        })
        console.log(that.data.addType)
        if (that.data.addType == 1) {
         wx.cloud.callFunction({
          // 云函数名称
          name: 'database',
          // 传给云函数的参数
          data: {
            type: 'getById',
            id: options.id
          },
          success: function(res) {
            that.setData({
              resource: res.result.data
            });
            console.log('sss', that.data.resource);
          },
          fail: function() {}
        })
    } else {
        options.order = JSON.parse(options.order)
        that.setData({
            order : options.order
        })
        console.log(that.data.order)
    }
    },

    getRecord: function() {
        var that = this;
        var data = that.data;
        wx.cloud.callFunction({
          // 云函数名称
          name: 'record',
          // 传给云函数的参数
          data: {
            type: 'get',
            getType: 'getData'
          },
          success: function(res) {
            console.log('获取成功', res);
            var result = res.result || {};
            that.setData({
              record: result.data,
            });
            console.log('record', data.record);
          },
          fail: function() {}
        })
      },

      submitOrder: function (e) {
        var resource = JSON.stringify(this.data.resource)
        var order = JSON.stringify(this.data.order)
        wx.showToast({
            title: '支付成功',
            icon: 'none'
          });
          if (this.data.addType == 1) {
            wx.cloud.callFunction({
                // 云函数名称
                name: 'record',
                // 传给云函数的参数
                data: {
                  type: 'upDate',
                  updateType: 'oneOrder',
                  id: this.data.record[0]._id,
                  name: this.data.resource.name,
                  image: this.data.resource.img,
                  price: this.data.resource.price,
                  _id: this.data.resource._id
                },
                success: function (res) {},
                fail: function () {}
              })
            wx.redirectTo({
                url: '/pages/bazaar/payResult/payResult?status=1&resource=' + resource
            });
       } else {
        wx.cloud.callFunction({
            // 云函数名称
            name: 'record',
            // 传给云函数的参数
            data: {
              type: 'upDate',
              updateType: 'moreOrder',
              id: this.data.record[0]._id,
              order: this.data.order,
            },
            success: function (res) {},
            fail: function () {}
          })
        wx.redirectTo({
            url: '/pages/bazaar/payResult/payResult?status=1&order=' + order
        });
       }
    },
})