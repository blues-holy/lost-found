Page({
  data: {
    resource: {},
    certificate: false,
    pickerNickName: '',
    picker: true
  },

  onLoad: function(options) {
    /**获得id**/
    var that = this;

    wx.cloud.callFunction({
      // 云函数名称
      name: 'database',
      // 传给云函数的参数
      data: {
        type: 'getById',
        id: options.id
      },
      success: function(res) {
        that.setData({
          resource: res.result.data
        });
        console.log('sss', res);
        if (!(that.data.resource.pickerOpenid == that.data.resource.users)) {
          that.setData({
            picker: false
          });
        } else {
          that.setData({
            picker: true
          });
        }
      },
      fail: function() {}
    })
      },

  getUserInfo: function(event) {
    console.log('用户信息', event);
    var that = this;
    var data = that.data;

    wx.getUserInfo({
      success: function(res) {}
    })
    that.setData({
      'pickerNickName': event.detail.userInfo.nickName
    });
    wx.cloud.callFunction({
      // 云函数名称
      name: 'database',
      // 传给云函数的参数
      data: {
        type: 'upDate',
        id: data.resource._id,
        updateType: 'picker',
        pickerNickName: data.pickerNickName,
      },
      /**将失主信息更新到云端**/
      success: function (res) {},
      fail: function () {}
    })
    that.setData({
      certificate: true
    });
  },

  onShareAppMessage: function(event) {
    return {
      title: '我捡的东西被认领啦~'
    }
  }
 })