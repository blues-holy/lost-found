const app = getApp()

Page({
    data: {
        record: [],
        choose: true,
        resource: [],
        price:0.00,
        cartCount: 0,
        order:[],
        chooseAll: true
    },
    onLoad: function() {
    this.getRecord();
    },

    getRecord: function() {
        var that = this;
        var data = that.data;
        var s = 0.00;
        wx.cloud.callFunction({
          // 云函数名称
          name: 'record',
          // 传给云函数的参数
          data: {
            type: 'get',
            getType: 'getData'
          },
          success: function(res) {
            console.log('获取成功', res);
            var result = res.result || {};
            that.setData({
              record: result.data,
            });
            that.setData({
              cartCount: data.record[0].cart.length,
            });
            for (let i = 0; i < data.record[0].cart.length; i++) {
               s = (Number(s) + Number(data.record[0].cart[i].price)).toFixed(2);
               console.log(s)
            }
            that.setData({
                price: s,
                chooseAll: true
              });
          },
          fail: function() {}
        })
      },

      noChoose: function(e) {
        var index = e.currentTarget.dataset.index;
        var data = this.data;
        var s = 0.00;
        var up = "record[0].cart[" + index + "].choose";//先用一个变量，把(info[0].gMoney)用字符串拼接起来
        this.setData({
          [up]:false,
        })
        s = (Number(data.price) - Number(data.record[0].cart[index].price)).toFixed(2);
        this.setData({
            price: s,
            cartCount: Number(data.cartCount) - 1
          })
      },  
      choose: function(e) {
        var index = e.currentTarget.dataset.index;
        var data = this.data;
        var s = 0.00;
        var up = "record[0].cart[" + index + "].choose";//先用一个变量，把(info[0].gMoney)用字符串拼接起来
        this.setData({
          [up]:true,
        })
        s = (Number(data.price) + Number(data.record[0].cart[index].price)).toFixed(2);
        this.setData({
            price: s,
            cartCount: Number(data.cartCount) + 1
          })
      },    
      chooseAll: function() {
      this.getRecord();
    },  
    
    noChooseAll: function() {
        for (let i = 0; i < this.data.record[0].cart.length; i++) {
        var up = "record[0].cart[" + i + "].choose";//先用一个变量，把(info[0].gMoney)用字符串拼接起来
        this.setData({
            [up]:false,
         })
        }
        this.setData({
            price: 0.00,
            cartCount: 0,
            chooseAll: false
          })
      },    
  

      checkoutOrder: function() {
        var data = this.data;
        for (let i = 0; i < data.record[0].cart.length; i++) {
            if (data.record[0].cart[i].choose == true) {
              data.order.push(data.record[0].cart[i])
            }
          }
          console.log(data.order)
        if (data.order.length <= 0) {
            util.showErrorToast('你好像没选中商品');
            return false;
        }
        var order = JSON.stringify(data.order)
        wx.navigateTo({
            url: '/pages/bazaar/order-check/index?addtype=' + 0 + '&order=' + order + '&price=' + data.price,
        })
    },    
})