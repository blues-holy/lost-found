function fixZero(num) {
    return num < 10 ? '0' + num : num;
  }
  /**时间格式为两位数**/
  
// 触底上拉刷新 TODO 这里要将page传给服务器，作者没写
Page({
    data: {
        order: [],
        record: [],
        orderCount: 0,
        orderList: [],
    },
    onLoad: function() {
        this.getRecord();
    },

    getRecord: function() {
        var that = this;
        var data = that.data;
        wx.cloud.callFunction({
          // 云函数名称
          name: 'record',
          // 传给云函数的参数
          data: {
            type: 'get',
            getType: 'getData'
          },
          success: function(res) {
            console.log('获取成功', res);
            var result = res.result || {};
            that.setData({
                record: result.data,
              });
              var order = data.record[0].order;
            that.dealData(order, function (data) {
                that.setData({
                    order: result.data,
                  });
            });      
            that.setData({
              orderCount: data.record[0].order.length,
              order: data.record[0].order
            });
            console.log('order', data.order);
          },
          fail: function() {}
        })
      },

      dealData: function (order, callback) {
        order.forEach(function (item) { /**循环遍历list**/
          var date = new Date(item.time);
    
          item.timeInfo = {
            year: date.getFullYear(),
            month: fixZero(date.getMonth() + 1),
            /**从0开始计算，所以加1**/
            date: fixZero(date.getDate()),
            hours: fixZero(date.getHours()),
            minutes: fixZero(date.getMinutes())
          };
        });
        callback(order);
      },
    
    onShow: function() {
        let showType = wx.getStorageSync('showType');
        let nowShowType = this.data.showType;
        let doRefresh = wx.getStorageSync('doRefresh');
        if (nowShowType != showType || doRefresh == 1) {
            this.setData({
                showType: showType,
                orderList: [],
                allOrderList: [],
                allPage: 1,
                allCount: 0,
                size: 8
            });
            // this.getOrderList();
            wx.removeStorageSync('doRefresh');
        }
        // this.getOrderInfo();
    },
    switchTab: function(event) {
        let showType = event.currentTarget.dataset.index;
        wx.setStorageSync('showType', showType);
        this.setData({
            showType: showType,
            orderList: [],
            allOrderList: [],
            allPage: 1,
            allCount: 0,
            size: 8
        });
        // this.getOrderInfo();
        // this.getOrderList();
    },
})