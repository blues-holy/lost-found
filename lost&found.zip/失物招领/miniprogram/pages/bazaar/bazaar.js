function fixZero(num) {
  return num < 10 ? '0' + num : num;
}
/**时间格式为两位数**/

Page({
  data: {
    claim: [],
    searchKey: '',
    search: [],
    bindtapSearch: false
  },
  onShow: function (options) {
    this.getBazaar();
  },

  getBazaar: function () {
    var that = this;
    wx.cloud.callFunction({
      // 云函数名称
      name: 'database',
      // 传给云函数的参数
      data: {
        type: 'get',
        getType: 'getBazaar'
      },
      success: function (res) {
        console.log('获取成功', res);
        var result = res.result || {};
        that.dealData(result.data, function (data) {
          that.setData({
            claim: result.data
          });
        });
      },
      fail: function () { }
    })
  },

  dealData: function (claim, callback) {
    claim.forEach(function (item) { /**循环遍历list**/
      var date = new Date(item.time);

      item.timeInfo = {
        year: date.getFullYear(),
        month: fixZero(date.getMonth() + 1),
        /**从0开始计算，所以加1**/
        date: fixZero(date.getDate()),
        hours: fixZero(date.getHours()),
        minutes: fixZero(date.getMinutes())
      };
    });
    callback(claim);
  },

  bindtapSearch: function () {
    var that = this;
    that.setData({
      bindtapSearch: true,
      search: []
    });
    that.getBazaar();
    /**重新搜索时获取全部数据**/
  },

  onInputSearch: function (event) {
    var that = this;
    var data = that.data;
    that.setData({
      search: [],
      'searchKey': event.detail.value,
      /**清除search之前的数据**/
    });
    for (let i = 0; i < data.claim.length; i++) {
      if (data.claim[i].name.indexOf(data.searchKey) >= 0) {
        data.search.push(data.claim[i].name)
      }
    }
  },
  /**实现关键字搜索功能**/

  onSearch: function (event) {
    this.getSearchData();
    this.setData({
      bindtapSearch: false,
      search: []
    });
  },

  getSearchData: function () {
    var that = this;
    wx.cloud.callFunction({
      // 云函数名称
      name: 'database',
      // 传给云函数的参数
      data: {
        type: 'get',
        getType: 'getBazaarSearchData',
        search: that.data.search
      },
      success: function (res) {
        console.log('获取成功');
        console.log(res);
        var result = res.result || {};
        that.dealData(result.data, function (data) {
          that.setData({
            claim: result.data
          });
        });
      },
      fail: function () { }
    })
  },

  button1: function () {
    this.setData({
      search: []
    });
    this.data.search.push('优盘');
    this.onSearch();
  },

  button2: function () {
    this.setData({
      search: []
    });
    this.data.search.push('雨伞');
    this.onSearch();
  },

  button3: function () {
    this.setData({
      search: []
    });
    this.data.search.push('读卡器');
    this.onSearch();
  },

  button4: function () {
    this.setData({
      search: []
    });
    this.data.search.push('内存卡');
    this.onSearch();
  },

  button5: function () {
    this.setData({
      search: []
    });
    this.data.search.push('笔记本');
    this.onSearch();
  },

  onOpenSearchDetail: function (event) {
    var dataset = event.currentTarget.dataset || {};
    var item = this.data.claim[dataset.index];
    /**item即列表第几个数据**/

    wx.cloud.callFunction({
      // 云函数名称
      name: 'database',
      // 传给云函数的参数
      data: {
        type: 'upDate',
        id: item._id,
        updateType: 'users',
      },
      /**记录点开失物用户的openid**/
      success: function (res) {
        wx.navigateTo({
          url: '/pages/bazaar/bazaarDetail/bazaarDetail?id=' + item._id,
        });
      },
      fail: function () { }
    })
  },

  onShareAppMessage: function (event) {
    return {
      title: '义卖的逾期失物，有需要的吗？'
    }
  }
})
