Page({
  data: {
    showAddBtn: true,
    showCode: false,
    /**默认展示图标，不展示二维码**/
    record: [],
    form: {
      img: '',
      question: '',
      answer: '',
      code: '',
      name: '',
      location: '',
      latitude: '',
      longitude: ''
    },
    honor: {
      claimName: '',
    },
    userInfo: {},
  },

  onLoad: function(options) {
    console.log(options)
    this.setData({
      'form.location': options.location,
      'form.latitude': options.latitude,
      'form.longitude': options.longitude,
    });
    var that = this;
    wx.login({
      success(res) {
        wx.cloud.callFunction({
          // 云函数名称
          name: 'getOpenid',
          // 传给云函数的参数
          data: {
            code: res.code
          },
          success: function(res) {
            res.result = JSON.parse(res.result);
            that.setData({
              userInfo: res.result
            });
          }
        })
      }
    })
  },
  /**获得用户openid**/

  uploadImg: function() { /**上传图片**/
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success: (res) => {
        this.setData({
          showAddBtn: false,
          /**上传图片后展示图片**/
          'form.img': res.tempFilePaths[0],
          /**图片临时路径**/
        });
      },
    });
  },

  onInputName: function(event) {
    this.setData({
      'form.name': event.detail.value
    });
  },

  onInputQuestion: function(event) {
    this.setData({
      'form.question': event.detail.value
    });
  },

  onInputAnswer: function(event) {
    this.setData({
      'form.answer': event.detail.value
    });
  },

  /**全局唯一标识符（GUID，Globally Unique Identifier）也称作 UUID(Universally Unique IDentifier) 。
  **/
  uuId: function(len, radix) {
    var chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'.split('');
    var uuid = [],
      i;
    radix = radix || chars.length;
    if (len) {
      // Compact form
      for (i = 0; i < len; i++) uuid[i] = chars[0 | Math.random() * radix];
    } else {
      // rfc4122, version 4 form
      var r;
      // rfc4122 requires these characters
      uuid[8] = uuid[13] = uuid[18] = uuid[23] = '-';
      uuid[14] = '4';
      // Fill in random data.  At i==19 set the high bits of clock sequence as
      // per rfc4122, sec. 4.1.5
      for (i = 0; i < 36; i++) {
        if (!uuid[i]) {
          r = 0 | Math.random() * 16;
          uuid[i] = chars[(i == 19) ? (r & 0x3) | 0x8 : r];
        }
      }
    }
    return uuid.join('');
  },

  onSave: function() {
    var form = this.data.form;
    var that = this;

    if (!form.img || !form.name || !form.question || !form.answer) {
      wx.showToast({
        title: '内容不能为空',
        icon: 'none'
      });
      return;
    }
    /**不能没有内容保存**/

    var cloudPath = that.uuId();
    /*生成唯一路径*/

    wx.cloud.uploadFile({
      cloudPath: cloudPath, // 上传至云端的路径
      filePath: form.img, // 图片路径
      success: function(res) {
        // 返回文件 ID
        /**图片保存到存储，fileID：存储地址**/
        that.setData({
          'form.code': "http://qr.liantu.com/api.php?text=" + cloudPath,
        });
        /**生成二维码**/
        that.addToDB(res.fileID); /**把地址传到数据库**/
        that.getRecord();
      },
      fail: function() {}
    })
  },

  getRecord: function(){
    var that = this;
    var data = that.data;
    wx.cloud.callFunction({
      // 云函数名称
      name: 'record',
      // 传给云函数的参数
      data: {
        type: 'get',
        getType: 'getData'
      },
      success: function (res) {
        console.log('获取成功', res);
        var result = res.result || {};
        that.setData({
          record: result.data
        });
        console.log('record',data.record);
        if(data.record.length == 0) {
          that.addToRecord();
        } else {
          that.updateRecord();
        }
      },
      fail: function () { }
    })
  },
  
  addToRecord: function() {
    var that = this;
    // honor.claimName.push(that.data.form.name);
    that.setData({
      'honor.claimName':that.data.form.name
    });
    wx.cloud.callFunction({
      // 云函数名称
      name: 'record',
      // 传给云函数的参数
      data: {
        type: 'add',
        claimName: that.data.honor.claimName,
        addType: 'claim'
      },
      success: function (res) {
        
      },
      fail: function () {
        console.log('fail')
      }
    });
  },

  updateRecord:function(){
    var data = this.data;
    this.setData({
      'honor.claimName': data.form.name
    });
    wx.cloud.callFunction({
      // 云函数名称
      name: 'record',
      // 传给云函数的参数
      data: {
        type: 'upDate',
        id: data.record[0]._id,
        updateType: 'claim',
        claimName: data.honor.claimName,
      },
      success: function (res) {},
      fail: function () {}
    })
  },

  addToDB: function(fileID) {
    var form = this.data.form;
    var that = this;
    wx.cloud.callFunction({
      // 云函数名称
      name: 'database',
      // 传给云函数的参数
      data: {
        type: 'add',
        img: fileID,
        question: form.question,
        answer: form.answer,
        code: form.code,
        name: form.name,
        location: form.location,
        latitude: form.latitude,
        longitude: form.longitude
      },
      success: function(res) {
        wx.showToast({
          title: '保存成功'
        });
        that.setData({
          showCode: true
        });
        /**展示二维码**/
      },
      fail: function() {
        console.log('fail')
      }
    });
  },
})
