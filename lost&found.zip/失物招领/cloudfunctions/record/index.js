// 云函数入口文件
const cloud = require('wx-server-sdk')
cloud.init(); /**初始化**/

var db = cloud.database(); /**取数据库**/

// 云函数入口函数
exports.main = async(event, context) => {
  console.log('调用云函数成功');
  console.log(event);
  /**日志在云开发-云函数里**/

  if (event.type === 'add') {
    return add(event, context);
  } else if (event.type === 'getById') {
    return getById(event, context);
  } else if (event.type === 'upDate') {
    return upDate(event, context);
  }
  return getData(event, context);
}

function add(event, context) {
  return new Promise(function(resolve, reject) {
    var data = {
      openid: event.userInfo.openId,
    };
    if (event.addType === 'claim') {
      data.done = [],
        data.claim = [{
          claimTime: Date.now(),
          claimName: event.claimName
        }],
        data.nickName = '',
        data.searchNumber = 0
    } else if (event.addType === 'newUser') {
      data.done = [],
        data.claim = [],
        data.searchNumber = 0,
        data.nickName = event.nickName
    } else if (event.addType === 'search') {
      data.done = [],
        data.claim = [],
        data.searchNumber = 1,
        data.nickName = event.nickName
    } else {
      data.done = [{
          doneTime: Date.now(),
          doneName: event.doneName
        }],
        data.claim = [],
        data.searchNumber = 0,
        data.nickName = event.nickName
    }
    db.collection('record').add({
      data: data,
      success: function(res) {
        resolve(res);
      },
      fail: function(err) {
        reject(err);
      }
    })
  });
}

function getData(event, context) {
  const _ = db.command
  if (event.getType === 'getData') {
    return db.collection('record').where({
      openid: event.userInfo.openId
    }).get();
    /**构建查询条件，展示未被认领的**/
  } else if (event.getType === 'getDoneRecord') {
    return db.collection('record').where({
      openid: event.openid
    }).get();
  } else if (event.getType === 'getPickerRecord') {
    return db.collection('claim').where({
      pickerOpenid: event.userInfo.openId
    }).get();
    /**构建查询条件，自己看到自己上传**/
  } else {
    return db.collection('claim').where({
      ownerOpenid: event.userInfo.openId
    }).get();
  }
}
/**构建查询条件，自己看到自己认领的**/
function getById(event, context) {
  return db.collection('claim').doc(event.id).get();
}
/**获取一个记录的数据**/

function upDate(event, context) {
  const _ = db.command
  const $ = event.index
  return new Promise(function(resolve, reject) {
    if (event.updateType === 'claim') {
      data = {
        claim: _.push([{
          claimTime: Date.now(),
          claimName: event.claimName
        }]),
      }
      /**改变招领状态，记录失主信息**/
    } else if (event.updateType === 'honor') {
      data = {
        nickName: event.nickName,
      }
      /**更新回答错误的失主openid**/
    } else if (event.updateType === 'search') {
      data = {
        nickName: event.nickName,
        searchNumber: event.searchNumber + 1
      }
      /**记录拾物者信息**/
    } else if (event.updateType === 'cart') {
      data = {
        cart: _.push([{
          name: event.name,
          image: event.image,
          price: event.price,
          choose: true
        }]),
      }
    } else if (event.updateType === 'oneOrder') {
      data = {
        order: _.push([{
          orderType: 1,
          time: Date.now(),
          name: event.name,
          image: event.image,
          price: event.price,
          _id: event._id
        }]),}
    } else if (event.updateType === 'moreOrder') {
      data = {
        order: _.push([{
          orderType: 2,
          time: Date.now(),
          order: event.order,
          price: Number(event.order[0].price) + Number(event.order[1].price)
        }]),}
    } else {
      data = {
        done: _.push([{
          doneTime: Date.now(),
          doneName: event.doneName
        }]),
      }
    }
    /**记录点开失物的用户的openid**/
    db.collection('record').doc(event.id).update({
      // data 传入需要局部更新的数据
      data: data,
      success: function(res) {
        resolve(res);
      },
      fail: function(err) {
        reject(err);
      }
    })
  });
}

