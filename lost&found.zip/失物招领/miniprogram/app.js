//app.js
App({
  onLaunch: function () {
    var storageData = wx.getStorageSync('postList');
    if (!storageData) {
      var dataObj = require("data/data.js")
      wx.clearStorageSync();
      wx.setStorageSync('postList', dataObj.postList);
    }
    this._getUserInfo();
    // wx.login();

    if (!wx.cloud) {
      console.error('请使用 2.2.3 或以上的基础库以使用云能力')
    } else {
      wx.cloud.init({
        // env 参数说明：
        //   env 参数决定接下来小程序发起的云开发调用（wx.cloud.xxx）会默认请求到哪个云环境的资源
        //   此处请填入环境 ID, 环境 ID 可打开云控制台查看
        //   如不填则使用默认环境（第一个创建的环境）
        // env: 'my-env-id',
        traceUser: true,
        env: 'node-6mzzn'  /*初始化*/
      })
    }
  },
    /* 在小程序端开始使用云能力前，需先调用 wx.cloud.init 方法完成云能力初始化（注意小程序需先开通云服务，开通的方法是点击工具栏左上角的 “控制台” 按钮）。因此，如果要使用云能力，通常我们在小程序初始化时即调用这个方法*/
    _getUserInfo: function () {
      var userInfoStorage = wx.getStorageSync('user');
      if (!userInfoStorage) {
        var that = this;
        wx.login({
          success: function () {
            wx.getUserInfo({
              success: function (res) {
                console.log(res);
                that.globalData.g_userInfo = res.userInfo
                wx.setStorageSync('user', res.userInfo)
              },
              fail: function (res) {
                console.log(res);
              }
            })
          }
        })
      }
      else {
        this.globalData.g_userInfo = userInfoStorage;
      }
    },
    globalData: {
      g_isPlayingMusic: false,
        g_currentMusicPostId: null,
          doubanBase: "http://t.yushu.im",
            g_userInfo: null
    },
})
