// 云函数入口文件
var cloud = require('wx-server-sdk');
var request = require('request');
/**request代码包**/

cloud.init()
/**初始化，在模板中也默认 require 了 wx-server-sdk，这是一个帮助我们在云函数中操作数据库、存储以及调用其他云函数的微信提供的库。**/

// 云函数入口函数
exports.main = async (event, context) => {
  return new Promise(function (resolve, reject) {
    request('https://api.weixin.qq.com/sns/jscode2session?appid=wx5894f3bb190ecce2&secret=a24db32391dc5cad6a885421395b050a&js_code=' + event.code + '&grant_type=authorization_code',
      function (err, response, body) {
        if (err) {
          reject(err);
          return;
        }
        resolve(body);
      });
  });
}
/**云函数的传入参数有两个，一个是 event 对象，一个是 context 对象。event 指的是触发云函数的事件，当小程序端调用云函数时，event 就是小程序端调用云函数时传入的参数，外加后端自动注入的小程序用户的 openid 和小程序的 appid。context 对象包含了此处调用的调用信息和运行状态，可以用它来了解服务运行的情况。**/
    // request('http://feedback.api.juhe.cn/ISBN?key=95021785564168120b580bc715adffe7&sub='+ event.ISBN,
// http://49.234.70.238:9001/book/worm/isbn?isbn=9787506811828
// https://douban.uieee.com/v2/book/