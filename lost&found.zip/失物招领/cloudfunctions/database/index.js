// 云函数入口文件
const cloud = require('wx-server-sdk')
cloud.init(); /**初始化**/

var db = cloud.database(); /**取数据库**/

// 云函数入口函数
exports.main = async(event, context) => {
  console.log('调用云函数成功');
  console.log(event);
  /**日志在云开发-云函数里**/

  if (event.type === 'add') {
    return add(event, context);
  } else if (event.type === 'getById') {
    return getById(event, context);
  } else if (event.type === 'upDate') {
    return upDate(event, context);
  } 
  return getData(event, context);
}

function add(event, context) {
  return new Promise(function(resolve, reject) {
    var data = {
      time: Date.now(),
      pickerOpenid: event.userInfo.openId,
      img : event.img,
      question : event.question,
      answer : event.answer,
      code : event.code,
      name : event.name,
      condition : false,
      bazaar: false,
      location:event.location,
      latitude:event.latitude,
      longitude:event.longitude,
      users : '',
      notOwner : [],
      ownerOpenid : '',
      ownerNickName : '',
      pickerNickName : '',
    };
    db.collection('claim').add({
      data: data,
      success: function(res) {
        resolve(res);
      },
      fail: function(err) {
        reject(err);
      }
    })
  });
}

function getData(event, context) {
  const _ = db.command
    if (event.getType === 'getData') {
      return db.collection('claim').where({
        condition: false,
        bazaar: false,
      }).get();
        /**构建查询条件，展示未被认领的**/
    } else if (event.getType === 'getSearchData') {
      return db.collection('claim').where({
        condition: false,
        name: _.in(event.search), 
        /**字段值在给定数组中，展示名称在搜索结果中的**/
      }).get();
    } else if (event.getType === 'getBazaarSearchData') {
      return db.collection('claim').where({
        condition: false,
        name: _.in(event.search), 
        bazaar: true,
        /**字段值在给定数组中，展示名称在搜索结果中的**/
      }).get();
    } else if (event.getType === 'getPickerRecord') {
      return db.collection('claim').where({
        pickerOpenid: event.userInfo.openId
      }).get();
      /**构建查询条件，自己看到自己上传**/
    } else if (event.getType === 'getBazaar') {
      return db.collection('claim').where({
        condition: false,
        bazaar: true,//查询无人认领超过六个月的逾期失物
      }).get();
    } else if (event.getType === 'getCentre') {
        return db.collection('centre').where({
      }).get();
    } else if (event.getType === 'getSearchCentre') {
        return db.collection('centre').where({
          name: _.in(event.search),
      }).get();
    } else {
      return db.collection('claim').where({
         ownerOpenid: event.userInfo.openId
      }).get();    
    }
}
  /**构建查询条件，自己看到自己认领的**/
function getById(event, context) {
  return db.collection('claim').doc(event.id).get();
}
/**获取一个记录的数据**/

function upDate(event, context) {
  return new Promise(function(resolve, reject) {
    if (event.updateType === 'owner') {
      data = {
        condition: true,
        ownerOpenid: event.userInfo.openId,
        ownerNickName: event.ownerNickName
      }
      /**改变招领状态，记录失主信息**/
    } else if (event.updateType === 'notOwner') {
      data = {
        notOwner: event.notOwner
      }
      /**更新回答错误的失主openid**/
    } else if (event.updateType === 'picker') {
      data = {
        pickerNickName: event.pickerNickName      
        } 
        /**记录拾物者信息**/
    } else {
      data = {
        users: event.userInfo.openId
      }
    }
    /**记录点开失物的用户的openid**/
    db.collection('claim').doc(event.id).update({
      // data 传入需要局部更新的数据
      data: data,
      success: function(res) {
        resolve(res);
      },
      fail: function(err) {
        reject(err);
      }
    })
  });
}