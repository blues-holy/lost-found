var app = getApp();
Page({
  data: {
    resource: {},
    record: [],
    cartCount: 0,
    addCart: false
  },

  onLoad: function(options) {
    /**获得id**/
    this.getRecord();
    var that = this;

    wx.cloud.callFunction({
      // 云函数名称
      name: 'database',
      // 传给云函数的参数
      data: {
        type: 'getById',
        id: options.id
      },
      success: function(res) {
        that.setData({
          resource: res.result.data
        });
        console.log('sss', res);
      },
      fail: function() {}
    })
  },


  getRecord: function() {
    var that = this;
    var data = that.data;
    wx.cloud.callFunction({
      // 云函数名称
      name: 'record',
      // 传给云函数的参数
      data: {
        type: 'get',
        getType: 'getData'
      },
      success: function(res) {
        console.log('获取成功', res);
        var result = res.result || {};
        that.setData({
          record: result.data,
        });
        that.setData({
          cartCount: data.record[0].cart.length
        });
        console.log('record', data.record);
      },
      fail: function() {}
    })
  },

 



  onShareAppMessage: function(event) {
    console.log(event)
    return {
      title: this.data.resource.name,
      path: '/pages/bazaarDetail/bazaarDetail?id=' + this.data.resource._id,
      imageUrl: this.data.image
    }
  },
  openCartPage: function() {
    wx.navigateTo({
      url: '/pages/bazaar/cart/cart',
    })
},

updateRecord: function() {
  var data = this.data;
  this.setData({
  cartCount: data.cartCount + 1
  })
  wx.cloud.callFunction({
    // 云函数名称
    name: 'record',
    // 传给云函数的参数
    data: {
      type: 'upDate',
      updateType: 'cart',
      id: data.record[0]._id,
      name: data.resource.name,
      image: data.resource.img,
      price: data.resource.price,
      choose: true
    },
    success: function (res) {
      wx.showToast({
        title: '添加成功',
    });
    },
    fail: function () {}
  })
  this.setData({
    addCart: true
    })
},

fastToCart: function() {
wx.navigateTo({
         url: '/pages/bazaar/order-check/index?addtype='+ 1 + '&id='+ this.data.resource._id
  });
 }
})